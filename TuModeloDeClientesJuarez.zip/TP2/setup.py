#setup.py
from setuptools import setup

setup(
    name="AzaPc",
    version="0.0.0.0.0.1",
    packages=["clases"],
    author="Ivan",
    author_email="ivanjuarez0999@gmail.com",
    description="Un paquete de ejemplo en Python"
)